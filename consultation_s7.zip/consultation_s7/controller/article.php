<?php

function articleSearchForm(){
    // Affichage page de recherche
    require('view/articleSearchFormView.php');
}

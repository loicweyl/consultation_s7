// Il existe moins de méthode pour sélectionner un nœud DOM
// avec les navigateurs historiques
var form  = document.getElementsByTagName('form')[0];
// var email = document.getElementById('mail');

var email = document.querySelectorAll("input[verif=true][orgn=input]");

var error = document.getElementById('error');

var delai=0; var pix=0; var pixmax=0; var inc=0;

// Pour respecter la spécification HTML5


// De nombreux navigateurs historiques ne supportent pas la méthode
// addEventListener. Voici une méthode simple (il en existe d'autres)
function addEvent(element, event, callback) {
  var previousEventCallBack = element["on"+event];
  element["on"+event] = function (e) {
    var output = callback(e);

    // Une fonction de rappel (callback) qui renvoie `false`
    // pour arrêter la chaîne des callback
    // et interrompre l'exécution du callback d'événement.
    if (output === false) return false;

    if (typeof previousEventCallBack === 'function') {
      output = previousEventCallBack(e);
      if(output === false) return false;
    }
  }
};

// On peut désormais reconstruire notre validation de contrainte
// Étant donné qu'on n'utilise pas la pseudo-classe CSS, il faut
// explicitement gérer la classe valid/invalid du champ e-mail
addEvent(window, "load", function () {
    var emailRegExp = /abc/ ;
    for (var i = 0; i < email.length; i++) {

       // Ici, on teste si le champ est vide (rappel : le champ n'est pas obligatoire)
      // S'il ne l'est pas, on vérifie que son contenu est une adresse e-mail valide.
      var test = email[i].value.length === 0 || emailRegExp.test(email[i].value);
      email[i].className = test ? "valid" : "invalid";
    }

});

// Ici, on définit ce qui se passe lorsque l'utilisateur
// saisit quelque chose dans le champ
addEvent(email, "keyup", function () {

    email.className = "valid";
    error.innerHTML = "";
    error.className = "error";

});

// Ici, on définit ce qui se passe lorsque l'utilisateur
// tente d'envoyer les données du formulaire
addEvent(form, "submit", function () {
      var emailRegExp = "/abc/" ;
      var nbError = 0;

    ' Initialisation des noeuds parents'

      for (var i = 0; i < email.length; i++) {
        emailRegExp = new RegExp("^\\s*" + email[i].getAttribute("answer1") +"\\s*$|^\\s*" + email[i].getAttribute("answer2")  +"\\s*$|^\\s*" + email[i].getAttribute("answer3")+"\\s$");
        var test = emailRegExp.test(email[i].value.toLowerCase());

          if (!test) {
            email[i].className = "invalid";
            error.className = "error active";
            nbError += 1 ;

          } else {
            email[i].className = "valid";
            error.innerHTML = "";
            error.className = "error";
          }
      }

    if (nbError > 0){
        error.innerHTML = "Mistake(s) : " + nbError ;
        ScrollUpToPage() ;
        return false ;
    }


});


function MomNavigateur() {
  if (navigator.appName=="Microsoft Internet Explorer") {
	pixscroll = document.documentElement.scrollTop;
  }
  else {
	pixscroll = window.pageYOffset;
  }
};

function ScrollUpToPage() {
	delai=1;
	inc=-20;
	MomNavigateur()
	pix = pixscroll;
	if (-inc > pixscroll) {
		if (pixscroll > 15) {inc = -pixmax+15;};
	}
	if (pixscroll > 15) {self.scrollTo(0,15);pixscroll=15;pix=15;inc=-5;}
	setTimeout("scroll()",delai);
};

function scroll() {
	pix=pix+inc;
	self.scrollBy(0,inc);
	if (pix >= 0) {
		setTimeout("scroll()",delai);
		MomNavigateur();
		if (pixscroll <= 5) {inc=-1;}
		if (pixscroll > 5) {if (pixscroll <= 10) {inc=-3;};}
		if (pix < pixscroll) {pix=0;};
	}
};

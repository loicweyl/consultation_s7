function afficherActionsPrecedentes(no_action,occ) {
   window.open("index.php?action=lastActions&act=" + no_action + "&occ=" + occ,"nom_de_la_fenetre","top=120,left=500,width=800,height=600");
}

//Creation du tableau
$(document).ready(function() {
    var table = $('#table_id').DataTable( {
        "language": {
            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/French.json"
         },
        "order": [[ 1, "asc" ]],
        "lengthMenu": [[20, 100, -1], [20, 100, "Toutes"]]
    } );

} );


var btn = document.getElementById('myonoffswitch') ;
var $_GET = $_GET()
var no_art = $_GET['no_art'] ;

function maj_boutton(){

    if (btn.getAttribute("etat")==1) { // A jour -> Tous
        document.location.href="http://10.1.23.8/visu_plan/index.php?action=search&search=all&no_art=" + no_art;
    } else {      // Tous -> A jour
        document.location.href="http://10.1.23.8/visu_plan/index.php?action=search&search=up-to-date&no_art=" + no_art;
    }
}

function $_GET(param) {
	var vars = {};
	window.location.href.replace( location.hash, '' ).replace(
		/[?&]+([^=&]+)=?([^&]*)?/gi, // regexp
		function( m, key, value ) { // callback
			vars[key] = value !== undefined ? value : '';
		}
	);

	if ( param ) {
		return vars[param] ? vars[param] : null;
	}
	return vars;
}

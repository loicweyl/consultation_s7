<?php
//***********************************
// CHARGEMENTS
//***********************************


// CHAGEMENT CONTROLLER
require('fonction.php');

// CHAGEMENT CONTROLLER
require('controller/article.php');

// CHAGEMENT DES CLASSES
//require_once('model/SylobManager.php');
//require_once('model/ArticleManager.php');
//require_once('model/PlanManager.php');
//require_once('model/DossierManager.php');

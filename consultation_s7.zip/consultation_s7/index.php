<?php

// Limite d'execution du script
set_time_limit(0) ; // Pas de limite

// CHARGEMENTS
require('chargements.php');

// Action when Browser is detected
//if(detect_os()=='Firefox'){
//	require('view/errorBrowserView.php');
//}
//else{
    if (isset($_GET['action'])) {
        if ($_GET['action']=="articleSearch"){
            articleSearchForm();
        }
        else{
            echo ('Pas encore déployé') ;
        }
    }
    else {
        // Page par défaut : formulaire de recherche
        articleSearchForm();
    }
//}


<?php
    $title = 'Recherche';

?>

<?php ob_start(); ?> <!--SCRIPT-->
	<!-- Aucun -->
<?php $script = ob_get_clean(); ?>

<?php ob_start(); ?> <!--CONTENT-->

   <div class=div_search>
		<form action="index.php" method="get" >
		    <div class='form_recherche'>

		      <input type="hidden" name="action" value="search"/>
                <input type="hidden" name="search" value="<?= $_GET['search'] ; ?>"/>

				<div class="form_ligne">
		            <h3 for="no_art">Article</h3>
		            <input type="text" name="no_art" placeholder="Article" class="typeahead" required/>
		        </div>

                <div class="form_ligne button_submit">
                    <input type="submit" value="Valider" class="button_submit"/>
                </div>
            </div>
		</form>
   </div>

<?php $content = ob_get_clean(); ?>

<?php require('view/template.php'); ?> <!--REQUIRE-->

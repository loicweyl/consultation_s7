<?php
    $title = 'Mise à jour';

?>

<?php ob_start(); ?> <!--SCRIPT-->
	<!-- Aucun -->
<?php $script = ob_get_clean(); ?>

<?php ob_start(); ?> <!--CONTENT-->


<div class=pla_general>
       <table id="table_id" class="display" style="width:100%">
           <thead>
                <tr>
                    <th>Dossier</th>
                    <th>Chemin</th>
                    <th>Frequence</th>
                    <th>Mise à jour</th>
                    <th>Nombre plans</th>
                    <th>Temps</th>
                </tr>
            </thead>
            <tbody>
               <?php
                $i = 0 ;

                    while ($dossier = $liste_dossier->fetch()){
                ?>
                        <tr>
                            <!--nom-->
                            <td class="article">
                                <?= $dossier['nom'] ; ?>
                            </td>

                            <!--chemin-->
                            <td class="designation">
                                <?= $dossier['chemin'] ; ?>
                            </td>

                            <!--frequence-->
                            <td class="frequence">
                                 <div class="div_frequence frequence_<?= $dossier['freq_id'] ; ?>"><?= $dossier['name'] ; ?></div>
                            </td>

                            <!--indice-->
                            <td class="update">
                                <?= $dossier['last_update'] ; ?>
                            </td>

                            <!--indice-->
                            <td class="files">
                                <?= $dossier['nb_files'] ; ?>
                            </td>

                            <!--indice-->
                            <td class="time">
                                <?= round($dossier['update_time']) ; ?> sec
                            </td>
                        </tr>
               <?php $i++ ; } ?>
        </table>

   </div>

<?php $content = ob_get_clean(); ?>

<?php require('view/template.php'); ?> <!--REQUIRE-->

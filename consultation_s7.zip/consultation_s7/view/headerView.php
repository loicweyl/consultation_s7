<div id="header_main">
    <h1 id="logo">
        <a href="index.php"> <img src="public/assets/images/RC_transparent.png">
            <div class="header_titre">
                <span>Consultation Sylob 7</span>
<!--
                <?php if (isset($_SESSION["util_intranet"])) { ?>
                    <em> Connecté :  <?= skip_accents(getInfoUtilisateur($_SESSION["util_intranet"])[0][0],'iso-8859-1') . " " . strtoupper(skip_accents(getInfoUtilisateur($_SESSION["util_intranet"])[0][1],'iso-8859-1')) ; ?> </em>
                <?php } else { ?>
                    <em> Non connecté </em>
                <?php } ?>
-->
            </div>
        </a>
    </h1>

    <nav id="header_nav">
        <ul>
<!--
            <li class="deroulant"><a href="index.php?action=searchView&search=up-to-date">Rechercher</a>
                <ul class="sous">
                    <li><a href="index.php?action=searchView&search=up-to-date">A jour</a></li>
                    <li><a href="index.php?action=searchView&search=all">Tous</a></li>
                </ul>
            </li>
-->

            <li class="current"><a href="index.php?action=articleSearch">Article</a></li>
            <li class="current"><a href="index.php?action=commandeVenteSearch" class="non-deploye">Commande vente</a></li>
            <li class="current"><a href="index.php?action=commandeAchatSearch" class="non-deploye">Commande achat</a></li>
            <li class="current"><a href="index.php?action=offreSearch" class="non-deploye">Offre de prix</a></li>
            <li class="current"><a href="index.php?action=fncSearch" class="non-deploye">FNC</a></li>
            <li style="white-space: nowrap;">
                <a href="index.php?action=deconnexion" class="button primary">Déconnexion</a>
            </li>
        </ul>
    </nav>
</div>

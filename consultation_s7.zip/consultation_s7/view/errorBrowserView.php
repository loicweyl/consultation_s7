<?php $title = 'Erreur'; ?>
<?php $description = 'Erreur'; ?>

<?php ob_start(); ?> <!--SCRIPT-->
	<!-- Aucun -->
<?php $script = ob_get_clean(); ?>

<?php ob_start(); ?> <!--CONTENT-->

   <div class=pla_be>
       <div class=erreur>
		  <p>Cette application ne fonctionne pas avec Firefox. Essayez avec un autre navigateur. </p>
       </div>
   </div>

<?php $content = ob_get_clean(); ?>

<?php require('view/template.php'); ?> <!--REQUIRE-->

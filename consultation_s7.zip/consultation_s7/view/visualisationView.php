<?php $description = 'Visualisateur plans'; ?>

<?php ob_start(); ?> <!--SCRIPT-->
	<!-- Aucun -->
<?php $script = ob_get_clean(); ?>

<?php ob_start(); ?> <!--CONTENT-->


   <div class=pla_general>

        <div class="onoffswitch">

            <input type="checkbox" name="onoffswitch" class="onoffswitch-checkbox" id="myonoffswitch" tabindex="0" onchange="maj_boutton()"
                   <?php if(((isset($_GET['search'])) && ($_GET['search']=='up-to-date') or (!isset($_GET['search'])))){ echo 'etat=1  checked '  ;}else{echo 'etat=0' ;} ?>>

                <label class="onoffswitch-label" for="myonoffswitch">
                    <span class="onoffswitch-inner"></span>
                    <span class="onoffswitch-switch"></span>
                </label>

        </div>

       <table id="table_id" class="display" style="width:100%">
           <thead>
                <tr>
                    <th>Article</th>
                    <th>Designation</th>
                    <th>Indice</th>
                    <th>Dossier</th>
                    <th>Plans</th>
                </tr>
            </thead>
            <tbody>
               <?php
                $i = 0 ;

                    while ($lignes = $liste_article->fetch()){
                ?>
                        <tr>
                            <!--action-->
                            <td class="article">
                                <?= $lignes['no_art'] ; ?>
                            </td>

                            <!--deisgnation-->
                            <td class="designation">
                                <?= skip_accents($lignes['designation'],'iso-8859-1') ; ?>
                            </td>

                            <!--indice-->
                            <td class="indice">
                                <?= $lignes['indice'] ; ?>
                            </td>

                            <!--dossier-->
                            <td class="dossier">
                                <div class="div_dossier color_<?= $lignes['color'] ; ?>"><?= $lignes['dossier_path'] ; ?></div>
                            </td>

                            <!--plans-->
                            <td class="plan">
                                <?php $plans = unserialize($lignes['plans']) ;
                                foreach ($plans as $plan){
                                ?>
                                    <a href="index.php?action=showPlan&path=<?= $plan[0] ; ?>&format=<?= $plan[1] ; ?>&art=<?= str_replace(' ','',$lignes['no_art']) ; ?>" class="btn btn-outline-secondary" target=_blank>
                                       <?php
                                            if ($plan[1] == "PDF"){
                                                include "public/svg/pdf.php" ;
                                            }
                                            elseif ($plan[1] == "DXF"){
                                                include "public/svg/dxf.php" ;
                                            }
                                            elseif ($plan[1] == "DWG"){
                                                include "public/svg/dwg.php" ;
                                            }
                                            elseif ($plan[1] == "SAT"){
                                                include "public/svg/sat.php" ;
                                            }
                                            elseif ($plan[1] == "STL"){
                                                include "public/svg/stl.php" ;
                                            }
                                            elseif (($plan[1] == "STEP") or ($plan[1] == "STP")){
                                                include "public/svg/cad.php" ;
                                            }
                                            elseif (($plan[1] == "PNG") or ($plan[1] == "JPG") or ($plan[1] == "JPEG")){
                                                include "public/svg/image.php" ;
                                            }
                                            else{
                                                include "public/svg/all.php" ;
                                            }


                                        ?>
                                    </a>

                                <?php } ?>
                            </td>
                        </tr>
               <?php $i++ ; } ?>
            </tbody>


        </table>
   </div>

<?php $content = ob_get_clean(); ?>

<?php require('view/template.php'); ?> <!--REQUIRE-->

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title><?= $title ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />

          <!-- Vendor -->
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/tagmanager/3.0.2/tagmanager.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>

        <!-- MAIN -->
        <link rel="stylesheet" href="public/assets/css/main.css" />
    </head>

    <body class="is-preload">

        <!--        Chargement page -->
        <div id="loader-wrapper">
            <div id="loader"></div>
            <div class="loader-section section-left"></div>
            <div class="loader-section section-right"></div>
        </div>

        <div id="page-wrapper">
            <header id="header" class="alt">
            	<?php include('headerView.php'); ?>
            </header>

            <?= $content ?>
        </div>

        <!-- Scripts d'origine modèle CSS -->
        <script src="public/assets/js/jquery.dropotron.min.js"></script>
        <script src="public/assets/js/jquery.scrolly.min.js"></script>
        <script src="public/assets/js/jquery.scrollex.min.js"></script>
        <script src="public/assets/js/browser.min.js"></script>
        <script src="public/assets/js/util.js"></script>
        <script src="public/assets/js/moment.js"></script>

        <!--        Loader-->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
	   <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.9.1.min.js"><\/script>')</script>
        <script src="public/assets/js/loader.js"></script>


         <!--        Chargement page -->
        <script type="text/javascript" src="http://code.jquery.com/jquery-latest.js"></script>
        <script type="text/javascript">
        $(window).load(function() {
        $(".loader").fadeOut("1000"); })
        </script>

        <!--        Script tableau-->
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">

        <script type="text/javascript" charset="utf8" src="https://code.jquery.com/jquery-3.3.1.js"></script>
        <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>

        <script src="public/assets/js/tableau_planificateur.js"></script>
        <script src="public/assets/js/planificateur.js"></script>
        <script src="public/assets/js/boutton_a_jour.js"></script>
    </body>
</html>
